import { NavLink, useLocation, useNavigate } from "react-router-dom";
import React, { useEffect, useState } from "react";
import { FaMoneyCheck } from "react-icons/fa";
import { AiOutlineLogout } from "react-icons/ai";
import { GiHamburgerMenu, GiTeacher } from "react-icons/gi";
import { MdDashboard } from "react-icons/md";
import { SiGoogleclassroom } from "react-icons/si";
import { TbHexagon3D, TbReport } from "react-icons/tb";
import { PiStudentBold } from "react-icons/pi";
import { HiDocumentReport } from "react-icons/hi";
import { TiSocialInstagramCircular } from "react-icons/ti";
import { GrProjects, GrTableAdd } from "react-icons/gr";
import { LuImport } from "react-icons/lu";
import { BiExport } from "react-icons/bi";
import { ImProfile } from "react-icons/im";
// import { clearUser } from "../redux/admin/adminSlice";
import { useDispatch, useSelector } from "react-redux";
import { IoIosPeople } from "react-icons/io";
import { RiAdminFill } from "react-icons/ri";
import { logoutUser } from "../store/UserSlice";
import logoTwo from "../assets/favicon_one.png";
import logoOne from "../assets/CRMGuruLogo.png";
import { IoSettings } from "react-icons/io5";
import { path } from "framer-motion/client";
import axios from "axios";
import { FaMeta, FaMoneyBills } from "react-icons/fa6";

const Sidebar = ({ isSidebarOpen, toggleSidebar }) => {
  const user = useSelector((state) => state.auth.user);
  console.log(user?.staff_role);
  const location = useLocation();
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const [subStatus, setSubStatus] = useState([]);

  const checkSubStatus = async () => {
    try {
      const { data } = await axios.get(
        `https://crm-generalize.dentalguru.software/api/checkSubscriptionValidity/${user?.staff_org_id}`,
        {
          headers: { Authorization: `Bearer ${user?.token}` },
        }
      );
      setSubStatus(data);
    } catch (error) {
      console.log(error);
      if (error?.response?.data?.message === "Unauthorized - Token Expired") {
        dispatch(logoutUser());
        navigate("/");
      }
    }
  };

  useEffect(() => {
    checkSubStatus();
  }, [user]);

  const menuItems = [
    ...(user?.staff_role === "superadmin"
      ? [
          {
            name: "Dashboard",
            path: "/dashboard",
            icon: <MdDashboard />,
          },

          {
            name: "Leads",
            path: "/super-admin-employee-leads",
            icon: <GrTableAdd />,
          },
          {
            name: "Digital Marketing Leads",
            path: "/social-media-superleads",
            icon: <FaMeta />,
          },

          {
            name: "Reports",
            path: "/super-admin-reporting",
            icon: <TbReport />,
          },
          {
            name: "Data Export",
            path: "/super-admin-data-export",
            icon: <BiExport />,
          },
          {
            name: "Projects",
            path: "/super-admin-project-dash",
            icon: <GrProjects />,
          },
          {
            name: "Employees Management",
            path: "/super-admin-employee-management",
            icon: <IoIosPeople />,
          },
          {
            name: "Settings",
            path: "/super-admin-settings",
            icon: <IoSettings />,
          },
          {
            name: "Finance Company Settings",
            path: "/finance-company-settings",
            icon: <FaMoneyBills />,
          },
        ]
      : []),

    ...(user?.staff_role === "admin"
      ? [
          {
            name: "Dashboard",
            path: "/dashboard",
            icon: <MdDashboard />,
          },

          {
            name: "Leads",
            path: "/leads",
            icon: <GrTableAdd />,
          },
          {
            name: "Digital Marketing Leads",
            path: "/main-social-media-leads",
            icon: <FaMeta />,
          },
          {
            name: "Reports",
            path: "/admin-report",
            icon: <TbReport />,
          },

          {
            name: "Data Export",
            path: "/data-export",
            icon: <BiExport />,
          },

          {
            name: "Projects",
            path: "/Project-Dash",
            icon: <GrProjects />,
          },
          {
            name: "Employees Management",
            path: "/employee-management",
            icon: <RiAdminFill />,
          },
        ]
      : []),

    ...(user?.staff_role === "employee"
      ? [
          {
            name: "Dashboard",
            path: "/dashboard",
            icon: <MdDashboard />,
          },

          {
            name: "Assigned Leads",
            path: "/employee-leads",
            icon: <GrTableAdd />,
          },
          {
            name: "Assigned Meta Leads",
            path: "/meta-leads-employee",
            icon: <FaMeta />,
          },
          {
            name: "Reports",
            path: "/employee-report",
            icon: <TbReport />,
          },
          {
            name: "Data Export",
            path: "/employee-data-export",
            icon: <BiExport />,
          },
        ]
      : []),
  ];

  const logoutHandler = () => {
    const isConfirmed = window.confirm("Are you sure you want to Logout?");
    if (isConfirmed) {
      dispatch(logoutUser());
      navigate("/");
    }
  };

  return (
    <div
      className={`${
        isSidebarOpen ? "w-60" : "w-12 sm:w-28"
      } h-screen fixed p-2 flex flex-col bg-white shadow-sm`}
    >
      {/* Top Logo and Hamburger */}
      <div className="flex items-center justify-between mb-4">
        <h1 className="text-md font-bold text-cyan-600">
          {isSidebarOpen ? (
            <>
              <img src={logoOne} alt="logo" srcset="" className="h-10 w-36" />
            </>
          ) : (
            <>
              <img src={logoTwo} alt="logo" srcset="" className="h-12 w-12" />
            </>
          )}
        </h1>
        <button
          onClick={toggleSidebar}
          className="p-2 text-gray-400 hover:text-gray-600 focus:outline-none text-2xl"
        >
          <GiHamburgerMenu />
        </button>
      </div>

      {/* Scrollable Menu */}
      <div className="flex-1 overflow-y-auto flex flex-col gap-4 thin-scrollbar">
        <nav className="flex flex-col gap-2">
          {menuItems.map((item, idx) => (
            <NavLink
              to={item.path}
              key={idx}
              className={({ isActive }) =>
                `flex items-center ${
                  isSidebarOpen
                    ? "justify-start gap-2 px-4"
                    : "justify-center text-xl"
                } py-2 rounded-md font-medium transition-all duration-200 ${
                  isActive
                    ? "bg-[#EEF0FF] text-cyan-600 rounded-xl"
                    : "text-gray-700 hover:text-cyan-800"
                }`
              }
              title={item.name}
            >
              <div className={isSidebarOpen ? "text-xl" : "text-2xl"}>
                {item.icon}
              </div>
              {isSidebarOpen && <span className="text-sm">{item.name}</span>}
            </NavLink>
          ))}
        </nav>

        {/* Logout Button */}
        <button
          className={`mt-auto bg-cyan-600 text-white py-2 rounded flex items-center ${
            isSidebarOpen ? "justify-start gap-2 px-4" : "justify-center"
          }`}
          onClick={logoutHandler}
        >
          <AiOutlineLogout />
          {isSidebarOpen && <span>Logout</span>}
        </button>
      </div>
    </div>
  );
};

export default Sidebar;
